name = "deepAntigen"
import logging
logging.getLogger('deepchem').setLevel(logging.CRITICAL)